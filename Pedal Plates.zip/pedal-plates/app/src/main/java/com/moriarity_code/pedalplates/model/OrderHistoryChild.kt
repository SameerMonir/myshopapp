package com.moriarity_code.pedalplates.model

data class OrderHistoryChild(
    val food_item_id: String,
    val name: String,
    val cost: String
)