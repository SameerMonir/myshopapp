package com.moriarity_code.pedalplates.model

data class Restaurants(
    val userId: String,
    val name: String,
    val rating: String,
    val cost_for_one: String,
    val img_url: String
)